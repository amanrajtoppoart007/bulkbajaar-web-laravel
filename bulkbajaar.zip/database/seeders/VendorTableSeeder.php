<?php

namespace Database\Seeders;

use App\Models\Vendor;
use Illuminate\Database\Seeder;

class VendorTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $vendors = [
            [
                'id'                 => 1,
                'name'               => 'Demo Vendor',
                'email'              => 'vendor@bulkbajaar.com',
                'password'           => bcrypt('password'),
                'remember_token'     => null,
                'approved'           => 1,
                'verified'           => 1,
                'verified_at'        => now(),
                'verification_token' => '',
                'mobile'             => '',
            ],
        ];

        Vendor::insert($vendors);
    }
}
